import React, { Component } from 'react'

export class Footer extends Component {
  render() {
    return (
      <div>
        <h2>footr class (using class componets)</h2>
      </div>
    )
  }
}

export default Footer
