import React from 'react'

export default function Fun() {
  return (
    <div>
      <h1>welcome to function compoents</h1>
    </div>
  )
}
