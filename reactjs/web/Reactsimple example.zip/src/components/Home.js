import React, { Component } from 'react'

export class Home extends Component {
  render() {
    return (
      <div>
        
        
      </div>
    )
  }
}

export default Home
