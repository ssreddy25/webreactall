import React from 'react'

const AboutsUs = () => {
  return (
    <div>
      <h1>aboutus compontes</h1>
    </div>
  )
}

export default AboutsUs
