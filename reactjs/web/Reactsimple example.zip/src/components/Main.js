import React, { Component } from 'react'

export class Main extends Component {
  render() {
    return (
      <div>
        <h1>main method (class compoents)</h1>
      </div>
    )
  }
}

export default Main
