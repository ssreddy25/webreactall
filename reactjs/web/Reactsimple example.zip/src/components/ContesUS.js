import React from 'react'

const contesUS = () => {
  return (
    <div>
      <h1>contesus compontes</h1>
    </div>
  )
}

export default contesUS
