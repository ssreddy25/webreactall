import React from 'react'

const Home1 = () => {
  return (
    <div>
      <h1>home page compnents</h1>
    </div>
  )
}

export default Home1
