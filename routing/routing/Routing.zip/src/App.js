
import './App.css';
import Nabar from './components/Nabar';

function App() {
  return (
    <div className="App">
      <Nabar/>
    </div>
  );
}

export default App;
