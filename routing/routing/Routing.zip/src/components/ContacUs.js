import React from 'react'

function ContacUs() {
  return (
    <div>
      <h2>wellcome to contas pages</h2>
    </div>
  )
}

export default ContacUs
