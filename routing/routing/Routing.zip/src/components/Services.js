import React from 'react'

function Services() {
  return (
    <div>
      <h2>wellcome to servies pages</h2>
    </div>
  )
}

export default Services
