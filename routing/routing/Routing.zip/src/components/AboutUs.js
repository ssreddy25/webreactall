import React from 'react'

function AboutUs() {
  return (
    <div>
      <h2>wellcome to abouts pages</h2>
    </div>
  )
}

export default AboutUs
