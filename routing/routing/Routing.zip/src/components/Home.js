import React from 'react'

function Home() {
  return (
    <div>
      <h2>wellcome to home pages</h2>
    </div>
  )
}

export default Home

